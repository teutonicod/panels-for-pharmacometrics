loess_dotted <-
function(x,y,colDotted="blue",col="green",lwd=2,observations=TRUE,colObservations="lightblue",quintiles=c(0.025,0.975),lty=3,...){
               myX <- sort(unique(x))
               lowerSide <- tapply(y,x,quantile,quintiles[1]) 
               upperSide <- tapply(y,x,quantile,quintiles[2]) 
               if (observations) panel.xyplot(x,y,col=colObservations,fill=colObservations,pch=21)
               panel.lines(myX,lowerSide,col=colDotted,lwd=lwd,lty=lty)
               panel.lines(myX,upperSide,col=colDotted,lwd=lwd,lty=lty)
               panel.loess(x,y,col=col,lwd=lwd,...)
}

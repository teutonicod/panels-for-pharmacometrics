loess_observations <-
function(x, y, col="green",lwd=2,colObservations="lightblue",...) {
                panel.xyplot(x, y,col=colObservations)
                panel.loess(x, y, lwd=lwd, col=col,...)
}

loess_shade <-
function(x,y,colShade="lightblue3",col="green",lwd=2,observations=TRUE,colObservations="lightblue",quantiles=c(0.025,0.975),...){
               myX <- sort(unique(x))
               lowerSide <- tapply(y,x,quantile,quantiles[1]) 
               upperSide <- tapply(y,x,quantile,quantiles[2])
               if (observations) panel.xyplot(x,y,col=colObservations,fill=colObservations,pch=21)
               panel.polygon(c(myX,rev(myX)),c(lowerSide,rev(upperSide)),
                             col=colShade,border=FALSE)  
               panel.loess(x,y,col=col,lwd=lwd,...)
}

mean_observations <-
function(x, y, col="green",lwd=2,colObservations="lightblue",...) {
                panel.xyplot(x, y,col=colObservations)
                mean <- tapply(y, x, mean)
                panel.lines(sort(unique(x)), mean, lwd=lwd, col=col,...)
}

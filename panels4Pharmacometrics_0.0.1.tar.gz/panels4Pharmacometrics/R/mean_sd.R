mean_sd <-
function(x,y,dx=NULL,...){

agg<-aggregate(y,list(x),function(x)c(mean(x,na.rm=TRUE),sd(x,na.rm=TRUE)))
myMean <- agg[,2][,1]
mySD <- agg[,2][,2]
dLowerVec <- myMean-mySD
dUpperVec <- myMean+mySD
  if (is.null(dx)) dx <- (max(agg[,1])-min(agg[,1]))/(3*length(unique(agg[,1])))
  panel.xyplot(agg[,1],myMean,...)
  lsegments(agg[,1],dLowerVec,agg[,1],
            dUpperVec,col="#ff00ff")
  lsegments(agg[,1]-dx,dLowerVec,agg[,1]+dx,
            dLowerVec,col="#ff00ff")
  lsegments(agg[,1]-dx,dUpperVec,agg[,1]+dx,
            dUpperVec,col="#ff00ff")
}

median_observations <-
function(x, y, col="green",lwd=2,colObservations="lightblue",...) {
                panel.xyplot(x, y,col=colObservations)
                median <- tapply(y, x, median)
                panel.lines(sort(unique(x)), median, lwd=lwd, col=col,...)
}

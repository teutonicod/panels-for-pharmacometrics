median_quantile <-
function(x,y,dx=NULL,quantiles=c(0.05,0.95),...){

agg<-aggregate(y,list(x),function(x)c(median(x,na.rm=TRUE),quantile(x, probs=quantiles, na.rm=TRUE)))
myMedian <- agg[,2][,1]
myLowerQuantile <- agg[,2][,2]
myUpperQuantile <- agg[,2][,3]
  if (is.null(dx)) dx <- (max(agg[,1])-min(agg[,1]))/(3*length(unique(agg[,1])))
  panel.xyplot(agg[,1],myMedian,...)
  lsegments(agg[,1],myLowerQuantile,agg[,1],
            myUpperQuantile,col="#ff00ff")
  lsegments(agg[,1]-dx,myLowerQuantile,agg[,1]+dx,
            myLowerQuantile,col="#ff00ff")
  lsegments(agg[,1]-dx,myUpperQuantile,agg[,1]+dx,
            myUpperQuantile,col="#ff00ff")
}

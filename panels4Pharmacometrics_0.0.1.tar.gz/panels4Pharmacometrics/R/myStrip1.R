myStrip1 <-
function(...)strip.default(...,strip.names=c(FALSE,TRUE),strip.levels=c(TRUE,TRUE),sep=": ")

myStrip2 <-
function(which.panel,factor.levels,...) {
                                myFactors <- length(factor.levels)
                                myInterval <-1/(myFactors+1)
                                myVec <- rep(myInterval, myFactors)
                                for (i in 1:myFactors) myVec[i] <- myVec[i]*i
                                font <- rep(1, myFactors)
                                font[which.panel] <- 2
                                col=rep("grey", myFactors)
                                col[which.panel] <- "black"
                                llines(c(0, 1, 1, 0, 0), c(0, 0, 1, 1, 0),col="black")
                                ltext(myVec, rep(0.5, myFactors), factor.levels,
                                font=font, col=col)
}

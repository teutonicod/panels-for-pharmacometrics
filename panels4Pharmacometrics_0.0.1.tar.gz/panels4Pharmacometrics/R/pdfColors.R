pdfColors <-
function(writeFile=FALSE,fileName="colors.pdf"){

plotFunction <- function(){

				n<-1:10
				x <- matrix(c(rep(1,length(n))))
				y<-colors()

				z<-as.data.frame(col2rgb(y))
				names(z)<-y
				nCycle<-ceiling(length(y)/10)

				j<-1
				while (j <nCycle){
               				y1<-y[1:10]
               				#isThereAnyGray <- grep("[:alnum:]*gray[:alnum:]*|[:alnum:]*grey[:alnum:]*",y1)
               				#isThereAnyBlack <- grep("[:alnum:]*black[:alnum:]*",y1)               
               				#if (length(isThereAnyGray)!=0|length(isThereAnyBlack)!=0) myCol<-"red" else myCol<-"black"
              			      barplot(x,col=y1[n],width=0.3,xlim=c(0,1),yaxt='n',main=paste("R Colors page",j))
               				for (i in 1:10) text(0.55,(0.5+i-1),y1[n[i]],col="black")
               				for (i in 1:10) text(0.8,(0.5+i-1),"RBG: ",col="black")
            			      for (i in 1:10) text(0.9,(0.7+i-1),paste("Red =",z[1,y1[n[i]]]),col="red",cex=0.7)
             		            for (i in 1:10) text(0.91,(0.5+i-1),paste("Green =",z[2,y1[n[i]]]),col="green2",cex=0.7)
              			      for (i in 1:10) text(0.9,(0.3+i-1),paste("Blue =",z[3,y1[n[i]]]),col="blue",cex=0.7)

             			      y <- y[-(1:10)]
             		           j<-j+1
						}
}

if(writeFile){
		pdf(fileName)
		plotFunction()
		dev.off()
		} else {
			windows(record=TRUE)
			plotFunction()
			}

}
